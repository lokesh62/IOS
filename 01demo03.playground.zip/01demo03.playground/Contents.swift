import UIKit

var greeting = "Hello, playground"
print("hi",10,12.5)
var name = "loki"
var grade = "88"
var Language = "Swift"
var age = 22
print("I am \(name), and grade is \(grade)")
print("i like \(Language) programming")
print("i am \(age) yers old and in \(age) years my age will be \(age*2) years")
print("welcome to", terminator: "")
print(" spring 2022")

print("The list of numbers are ", terminator: "")
print(1,2,3,4,5,6)
print("The new pattern is", terminator: "#")
print( 1,2,3,4,5,6, separator: "-")
var mobileBrand = "samsung"
mobileBrand = "google"
print("mobile brand is",mobileBrand)
var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")
print(10,20,30)
print( 12.5,15.5)
var httpError  = (errorCode : 404  , errorMessage :"Page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )
var Name = ("John","Smith")
var fName = Name.0
var lName = Name.1
print(fName , terminator : ",")
print(lName)
let city = (name : "Maryville" , population : 11000)
let ( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)
let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))
var fname = "Joe"
var lname = "Root"
(fname , lname) = (lname , fname)
print("First Name is \(fname) and Last Name is \(lname)")
var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
var number = (1,1)
var num = (1,1)
print(number>num)
var character:Int = "A";
print(type(of: character))

